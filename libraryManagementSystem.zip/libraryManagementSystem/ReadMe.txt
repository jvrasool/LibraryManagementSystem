the c#/.NET project(library) contains all the files essential for the library management system

1.Home page containg all the options.
2.Add book have further 2 options
	2a. RemoveBook
	2b. EditBook

Thank You for considering my work.