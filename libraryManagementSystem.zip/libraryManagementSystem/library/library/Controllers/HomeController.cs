﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using library.Models;

namespace library.Controllers
{
    public class HomeController : Controller
    {
        DataClasses1DataContext dc = new DataClasses1DataContext();
        // GET: Default
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult addbook()
        {
            return View(dc.Books.ToList());
        }
        public ActionResult add()
        {
            string name = Request["BookName"];
            string id = Request["BookID"];
            Book b = new Book();
            b.BookName = name;
            b.BookID = id;
            b.IssueStatus = 0;
            dc.Books.InsertOnSubmit(b);
            dc.SubmitChanges();
            return RedirectToAction("addbook");
        }
        public ActionResult removebook(string ID)
        {
            var b = dc.Books.First(x => x.BookID == ID);
            dc.Books.DeleteOnSubmit(b);
            dc.SubmitChanges();
            return RedirectToAction("Index");
        }
        public ActionResult editbook(string ID)
        {
            return View(dc.Books.First(c => c.BookID == ID));
        }
        public ActionResult edit(string ID)
        {
            var b = dc.Books.First(s => s.BookID == ID);
            b.BookName = Request["BookName"];
            dc.SubmitChanges();
            return RedirectToAction("Index");
        }
        public ActionResult issuebook()
        {
            return View();
        }
        public ActionResult returnbook()
        {
            return View();
        }
        public ActionResult returndate()
        {
            return View();
        }
        public ActionResult searchbook()
        {
            return View();
        }
        public ActionResult search()
        {
            return View();
        }

    }
}